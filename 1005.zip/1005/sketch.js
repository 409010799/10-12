function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  //background("#666a86");
  //let r_y = mouseY/3 //let宣告變數為區域變數
  var r_x = mouseX/8 //var宣告半數為全域變數
  var R = mouseX/8
  var G = mouseY/4
  var B = frameCount%256
  fill(R,G,B)
  ellipse(width/2,height/4,r_x)
  ellipse(width/2,height/3,r_x)
  ellipse(width/2,height/2,r_x)
  ellipse(width/2,height*2/3,r_x)
  ellipse(width/2,height*3/4,r_x)
}
